from downloader.downloader import (
    auto_download,
    split_and_download
)