from doujinshi.modules import *
import re
from doujinshi.BaseDownloader import Doujinshi

class GenericDownloaderError(Exception):
    pass

PATTERN_CLASS_MAP = {
    r'\/\/doujins\.com\/': DoujinsCom,
    r'\:\/\/doujin\.sexy\/': DoujinSexy,
    r'\:\/\/hentaifox\.com\/' : HentaiFox,
    r'\:\/\/hitomi\.la': Hitomi,
    r'\:\/\/nhentai\.net': NHentai, 
    r'\:\/\/nhentai\.to': NHentai, 
    r'\:\/\/nhentai\.xxx': NHentai,
    r'\:\/\/9hentai\.to\/': NineHentai,
    r'\:\/\/3hentai\.net': ThreeHentai,
    r'\:\/\/hentai2read\.com': Hentai2Read,
    r'\:\/\/(?:[^\.]+\.)?tsumino\.com\/': Tsumino,
    r'\:\/\/hentaiera\.com': HentaiEra,
    r'\:\/\/imhentai\.xxx': ImHentaiXXX,
    r'\:\/\/hentaienvy\.com': HentaiEnvy,
    r'\:\/\/hentaizap\.com': HentaiZap,
    r'\:\/\/comics\.8muses\.com': EightMuses
}
def doujin_class(full_url:str):
    for pattern, class_ in PATTERN_CLASS_MAP.items():
        if bool(re.search(pattern, full_url, re.I)):
            return class_
    raise GenericDownloaderError(f"No downloader found for URL: `{full_url}`")

def doujin_download(full_url:str) -> Doujinshi:
    """`full_url :` Full URL of a Doujin"""
    class_ = doujin_class(full_url)
    return class_(full_url)