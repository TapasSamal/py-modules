from doujinshi.BaseDownloader import (
    Doujinshi,
    Union
)

class NHentai(Doujinshi):
    def __init__(self, info:Union[str,int]) -> None:
        """`info`: either full URL or just the ID"""
        super().__init__()
        self._site_map = {
            'fetch_url': "https://nhentai.net/api/gallery/{id}",
            're_check':[r'^\d+$', r'\:\/\/nhentai\.net', r'\:\/\/nhentai\.to', r'\:\/\/nhentai\.xxx'],
            'id_find': r'/\w+\/(\d+)',
            'referer': 'https://nhentai.net/'
        }
        self._init(info)
        self.meta_data = dict()
        self.__ext_type_map={
            'j':'jpg',
            'p':'png',
            'g':'gif',
            'w':'webp',
            'a':'avif'
        }
        self.__info_extractor()
        
    def __ext_match_(self,ext_type:str):
        ext=self.__ext_type_map.get(ext_type)
        if ext is None:
            raise RuntimeError(f"ext type `{ext_type}` did not match")
        return ext
    
    def __info_extractor(self) -> None:
        data = self._requests(self.url)
        result = data.json()
        self.title = result['title']['english']
        self.title_pretty = self._pretty_title(result['title']['english'])
        for tag in result['tags']:
            tag_type=tag['type']
            tag_name=tag['name']
            if self.meta_data.get(tag_type) is None:
                self.meta_data[tag_type]=[tag_name]
            else:
                self.meta_data[tag_type].append(tag_name)
        self.images = [f"https://i.nhentai.net/galleries/{result['media_id']}/{i}.{self.__ext_match_(d['t'])}" for i,d in enumerate(result['images']['pages'], start=1)]
        self.cbz_name = self._cbz_name(self.title_pretty, f'nhentai.net ({self.id})' ,self.meta_data.get('artist'), self.meta_data.get('group'))



# export const api = {
#   nhentai: {
#     gallery: (id: number) => `https://nhentai.net/api/gallery/${id}`,

#     browse: (page: number, query: string, sorting: string) => {
#       const searchParams = new URLSearchParams({
#         query: query,
#         page: page.toString(),
#         sort: sorting,
#       });
#       return `https://nhentai.net/api/galleries/search?${searchParams.toString()}`;
#     },

#     page: (media_id: number, index: number, type: "j" | "p") => {
#       const extension = type === "j" ? "jpg" : "png"
#       return `https://t3.nhentai.net/galleries/${media_id}/${index + 1}t.${extension}`;
#     },

#     pageHighDefinition: (media_id: number, index: number, type: "j" | "p") => {
#       const extension = type === "j" ? "jpg" : "png"
#       return `https://i.nhentai.net/galleries/${media_id}/${index + 1}.${extension}`;
#     },

#     thumbnail: (media_id: number, type: "j" | "p") => {
#       const extension = type === "j" ? "jpg" : "png"
#       return `https://t3.nhentai.net/galleries/${media_id}/thumb.${extension}`;
#     },

#     home: (page: number) =>
#       `https://nhentai.net/api/galleries/all?page=${page}`
#   }
# } as const

# export type Sorting =
#   | "recent"
#   | "popular-today"
#   | "popular-week"
#   | "popular"
#   | "popular-month";

# export type SearchQuery = "*" | string