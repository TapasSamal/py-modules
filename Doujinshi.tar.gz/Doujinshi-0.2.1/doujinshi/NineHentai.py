from doujinshi.BaseDownloader import (
    Doujinshi,
    Union
)

class NineHentai(Doujinshi):
    def __init__(self, info:Union[str,int]) -> None:
        """`info`: either full URL or just the ID"""
        super().__init__()
        self._site_map = {'re_check':[r'^\d+$', r'\:\/\/9hentai\.to\/'], 'id_find':r'/\w+\/(\d+)', 'referer':'https://9hentai.to/', 'fetch_url':"https://9hentai.to/g/{id}/"}
        self._init(info)
        self.meta_data = dict()
        self.__info_extractor()
    def __info_extractor(self):
        soup = self._make_soup(self._requests(self.url).content)
        for tag in soup.select("section#tags > div.tag-container"):
            listed_tags=list(tag.stripped_strings)
            self.meta_data[listed_tags[0].strip(':').lower()] = listed_tags[1:]
        book_data = self._requests("https://9hentai.to/api/getBookByID", "POST", {"id": self.id}).json()['results']
        self.title = book_data.get('alt_title')
        self.title_pretty = self._pretty_title(book_data.get('title'))
        self.cbz_name = self._cbz_name(self.title_pretty, f'9hentai.to ({self.id})' ,self.meta_data.get('artist'), self.meta_data.get('group'))
        self.images = [book_data['image_server'] + self.id + f"/{i}.jpg" for i in range(1, book_data['total_page'] + 1)]