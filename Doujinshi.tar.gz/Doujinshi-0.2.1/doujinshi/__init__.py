from doujinshi.GenericDownloader import doujin_download
from doujinshi.modules import *