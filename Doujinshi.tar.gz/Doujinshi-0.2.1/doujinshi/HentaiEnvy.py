from doujinshi.BaseHeantaiEra import BaseHentaiEra
from typing import Union

class HentaiEnvy(BaseHentaiEra):
    def __init__(self, info:Union[str,int]) -> None:
        """`info`: either full URL or just the ID"""
        super().__init__()
        self._site_map = {'re_check':[r'^\d+$', r'\:\/\/hentaienvy\.com'],'id_find': r'/\w+\/(\d+)','referer': 'https://hentaienvy.com/','fetch_url': "https://hentaienvy.com/gallery/{id}/"}
        self._init(info)
        self._title_selector = "div.gt_right > h1"
        self._cover_selector = "div.gt_left > img"
        self._tag_name_selector = "div.gt_right_tags span.tag_title"
        self._tags_sibling_selector = 'li > a.gp_tag'
        self._info_extractor()