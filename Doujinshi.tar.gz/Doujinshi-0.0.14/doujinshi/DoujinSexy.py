from doujinshi.BaseDownloader import (
    Doujinshi,
    os
)

class DoujinSexy(Doujinshi):
    def __init__(self, URL:str) -> None:
        """`info`: ONLY GIVE full URL"""
        super().__init__()
        self._site_map = {'fetch_url': "https://api.doujin.sexy/v3/album/{id}", 're_check':[r'\:\/\/doujin\.sexy\/'],'id_find': r'\/([^\/]+)\/?(?:read\/\d+)?$','referer': 'https://doujin.sexy/'}
        self._image_name_split = "?"
        self._init(URL)
        self.meta_data = dict()
        self.__info_extractor()

    def __info_extractor(self):
        data = self._requests(self.url).json()['data']
        self.title = data['title']
        self.title_pretty = self._pretty_title(self.title)
        t,p,c,a = tuple(map(lambda x: None if len(data[x]) == 0 else [i['title'] for i in data[x]], ['tags', 'parodies', 'characters', 'artists']))
        s, l=data['series']['title'], data['language']['name']
        self.meta_data = {
            'tags':t, 'parodies':p, 'characters':c, 'artists':a, 'series':s, 'language':l
        }
        self.cbz_name = self._cbz_name(self.title_pretty, 'doujin.sexy', self.meta_data.get('artists'))
        pages = data = self._requests(self.url + '/pages').json()['data']['pages']
        self.images = list(map(lambda i: i['sizes']['full'] + f"?{i['page_num']}{os.path.splitext(i['sizes']['full'])[-1]}", pages))