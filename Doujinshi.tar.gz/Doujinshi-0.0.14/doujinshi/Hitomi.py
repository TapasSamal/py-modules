from doujinshi.BaseDownloader import (
    Doujinshi,
    re,
    Union,
    os
)
import json
from urllib.parse import urlparse, urlunparse

class Hitomi(Doujinshi):
    def __init__(self, info:Union[str,int]) -> None:
        """`info`: either full URL or just the ID"""
        super().__init__()
        self._site_map = {'fetch_url': "https://ltn.hitomi.la/galleries/{id}.js", 're_check':[r'^\d+$', r'\:\/\/hitomi\.la'],'id_find': r'(?:\-|\/)(\d+)\.\w{4}','referer': 'https://hitomi.la/'}
        self._n_sort_image_name = False
        self._image_name_split = '?'
        self._init(info)
        self.meta_data = dict()
        self.__info_extractor()
        
    @property
    def images(self) -> list:
        images = getattr(self, '__images', None)
        if images is not None:
            return images
        self._number_case, self._time_path = self.__get_number_case()
        ext = 'webp'
        data = [self._url_from_dict(img, ext) + f"?{os.path.splitext(img['name'])[0]}.{ext}" for img in self.__files]
        setattr(self, '__images', data)
        return data

    def __info_extractor(self):
        text = self._requests(self.url).text
        search = re.search(r"^[^\{]+(.+)$", text)
        if not search: raise ValueError(f"JSON data not found")
        galleryinfo = json.loads(search.group(1))
        self.__files = galleryinfo['files']
        self.title = galleryinfo['title']
        for d in ['title','id','related','files','blocked', 'date', 'galleryurl', 'language_localname', 'language_url', 'languages', 'scene_indexes', 'video', 'videofilename']:
            try:del galleryinfo[d]
            except KeyError:pass
        map = {"tags":'tag',"artists":'artist',"groups":'group',"parodys":'parody',"characters":'character'}
        for k, v in galleryinfo.items():
            if v is not None:
                if type(v) == list:self.meta_data[k] = [i[map[k]] for i in v]
                else:self.meta_data[k] = v
        self.title_pretty = self._pretty_title(self.title)
        self.cbz_name = self._cbz_name(self.title_pretty, f'hitomi.la ({self.id})' ,self.meta_data.get('artists'), self.meta_data.get('groups'))

    def _s(self, h):
        r = re.compile(r"(..)(.)$").search(h).groups()
        return str(int(r[1] + r[0], 16))
    def _subdomain_from_url(self, url, base):
        m = re.compile(r'\/[0-9a-f]{61}([0-9a-f]{2})([0-9a-f])').search(url)
        if not m: return 'a'
        g = int(m.group(2) + m.group(1), 16)
        _1_0 = self._if_case_true if str(g) in self._number_case else self._if_case_false
        return chr(97 + int(_1_0)) + base
    def _url_from_url(self, url, base):
        p = urlparse(url)
        return urlunparse((p.scheme, self._subdomain_from_url(url, base)+ '.' + '.'.join(p.netloc.split('.')[1:]) , p.path, None, None, None))
    def _url_from_dict(self, image:dict, ext:str = "webp") -> str:
        return self._url_from_url(f"https://a.hitomi.la/{ext}/{self._time_path}/{self._s(image['hash'])}/{image['hash']}.{ext}", 'a')

    def __get_number_case(self) -> list:
        req = self._requests("https://ltn.hitomi.la/gg.js")
        text = req.text
        self._if_case_true, self._if_case_false = tuple(map(lambda p: re.search(p,text).group(1), [r"o = (\d); break", r"var o = (\d)"]))
        return ( re.findall(r'case (\d+):', text), re.findall(r"'(\d+)/'", text)[0] )