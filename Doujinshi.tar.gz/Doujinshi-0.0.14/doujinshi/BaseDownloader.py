from requests import request, Response
from urllib.parse import urlparse, unquote
from typing import Optional, Union, Tuple
from bs4 import BeautifulSoup
from zipfile import ZipFile
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor
import os
import regex as re # [ pip install regex ] (built-in re did not support `recursive patterns`)
from doujinshi.errors import *

class Doujinshi:
    def __init__(self) -> None:
        self.headers = {"Referer": "","User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
        self._n_sort_image_name = True
        self._image_name_split = '/'
        self.custom_cover_url = None

    def _init(self, info:Union[str,int]) -> None:
        info = str(info)
        self._check_validity(info, self._site_map['re_check'])
        self.id = self._get_id(self._site_map['id_find'], info)
        self.headers['Referer'] = self._site_map['referer']
        self.url = self._site_map['fetch_url'].format(id=self.id)

    def _pretty_title(self, title:str) -> str:
        clear_brackets = re.sub(
            r'([\[(][^[\]()]*(?:(?R)[^[\]()]*)*[\])])', '' , title
        )
        clean_space = re.sub(r"\s{2,}", " ", clear_brackets)
        splited = clean_space.split('|')
        return splited[-1].strip() if splited[-1].strip() != "" else splited[0].strip()

    def _cbz_name(self, title:str, site_domain:str, artist:Optional[list[str]]=None, group:Optional[list[str]]=None, extra:Optional[str]=None) ->str:
        title = title[:70]+"..." if len(title) > 75 else title
        add = ""
        ext = f" [{extra}]" if extra else ''
        if artist != None:add = f"[{', '.join(artist)}] "
        elif group != None:add = f"[{', '.join(group)}] "
        return self._sanitize_filename(add + title + ext + f" [{site_domain}].cbz")

    def _check_validity(self, info:Union[str, int], patterns:list):
        valid = False
        for p in patterns:
            valid = self._regex_exist(p, info)
            if valid:break
        if not valid: raise DoujinSiteError(f"`{info}` is not a valid arg for this class")

    def _regex_exist(self, pattern:str, text:str) -> bool:
        return bool(re.search(pattern, text, re.I))

    def _get_id(self, pattern:str, url:str) -> str:
        finds = re.findall(r'^\d+$', url, re.I)
        if len(finds) != 0: return finds[0]
        finds = re.findall(pattern, url, re.I)
        if len(finds) == 0: raise MatchFoundError(f"no ID found in `{url}`")
        else: return finds[0]

    def _requests(self, url:str, method:str="GET", data:Optional[dict]=None, stream:Optional[bool]=None, allow_redirects:bool=True) -> Response:
        req = request(method, url, data=data, stream=stream, allow_redirects=allow_redirects, headers=self.headers)
        if not req.ok:
            parsed_url = urlparse(req.url)
            raise ConnectionError(f"status_code: {req.status_code}, domain:{parsed_url.netloc}, path: {parsed_url.path}")
        return req

    def _make_soup(self, html_content:Union[str,bytes]):
        return BeautifulSoup(html_content, "lxml")

    def _sanitize_filename(self, string:str) -> str:
        res = ''
        def replace_(char):
            return {'/': '\u29F8', '\\': '\u29f9'}.get(char, chr(ord(char) + 0xfee0)) if char in '"*:<>?|/\\' else char
        for c in string:res = res + replace_(c)
        return res
        
    def _page_filter(self, filter_string:str,total_pages:int) -> list[int]:
        """returns 0 index page list\nSort pages in order """
        class ModList(list):
            def index(self,v):
                try: return super().index(v)
                except ValueError: return -1
        def SuperInt(s):
            try: return int(s)
            except (TypeError, ValueError): return None

        test_pattern = re.compile(r"^(!?\d*(-\d*(\/\d+)?)?\s*,\s*)*!?\d*(-\d*(\/\d+)?)?$")
        if not test_pattern.search(filter_string):
            raise RegexPatternError('The format of Pages Range is incorrect.')
        filter_string = re.sub(r", ", ",", filter_string).strip().strip(',')
        pages_range = []
        if filter_string[0] == '!' : filter_string = '1-,' + filter_string
        pattern = re.compile(r"!?(?:(\d*)-(\d*))(?:\/(\d+))?|!?(\d+)")
        matches = pattern.finditer(filter_string)
        for match_ in matches:
            selected=ModList()
            single = match_.group(4)
            if str(single).isnumeric(): selected.append(int(single))
            else:
                begin = SuperInt(match_.group(1)) or 1
                end = SuperInt(match_.group(2)) or total_pages
                mod = SuperInt(match_.group(3)) or 1
                if begin > end : begin, end = end, begin
                for i in range(begin, end+1, mod): selected.append(i)
            if match_.group(0)[0] == '!':
                pages_range = list(filter(lambda x: selected.index(x) < 0, pages_range))
            else:
                pages_range += selected

        return list(map(lambda i:i-1, set(pages_range)))
        
    def _make_tempzip(self, images:list[str], total_retries:int=10, concurrent_downloads:int = 20, path:Optional[Union[str, os.PathLike]]=None):
        filename_split, natural_sort = self._image_name_split, self._n_sort_image_name
        if path:
            ZIP = ZipFile(path, 'w')
        else:
            temp_zip = BytesIO()
            ZIP=ZipFile(temp_zip, 'w')

        total_images_decimal = len(str(len(images)))

        def image_name_maker(image_name:str, do_sort=True) -> str:
            image_name = unquote(image_name)
            if not do_sort: return image_name
            img_n, _ = os.path.splitext(image_name)
            len_img_n = len(img_n)
            add_ = ''
            if (total_images_decimal - len_img_n) < 0:return image_name
            for i in range(total_images_decimal - len_img_n):add_ = add_ + '0'
            return add_ + image_name

        def thread_image_handel(img_url:str)->None:
            img = self._requests(img_url, stream=True)
            img_name = image_name_maker(img_url.split(filename_split)[-1], natural_sort)
            if not img.ok:print('err ', img.status_code, " :: img_name '", img_name,"'")
            else:ZIP.writestr(img_name,img.content)

        def process(urls:list, tries=1):
            with ThreadPoolExecutor(max_workers=concurrent_downloads) as e: e.map(thread_image_handel, urls)
            not_downloaded = [item for item in urls if image_name_maker(item.split(filename_split)[-1], natural_sort) not in ZIP.namelist()]
            if len(not_downloaded) != 0 and tries > total_retries:raise ChildProcessError("[Error] Could not download all files")
            elif len(not_downloaded) != 0:tries += 1;process(not_downloaded,tries)

        process(images)
        if self.custom_cover_url:
            try:
                img = self._requests(self.custom_cover_url, stream=True)
                ZIP.writestr("00000_cover"+ os.path.splitext(self.custom_cover_url)[1], img.content)
            except:
                print("[log] error while trying to add custom cover")
        ZIP.close()
        if path:
            return None
        temp_zip.seek(0)
        return temp_zip

    def _get_range_images(self, pages_range:str) -> list[str]:
        images_len = len(self.images)
        index_ranges = self._page_filter(pages_range, images_len)
        return [self.images[i] for i in index_ranges]

    def download_cbz(self, save_path:str, pages_range:Optional[str]=None, concurrent_images:int=20, retries:int=10, resize_image=False) -> None:
        """ `save_path:` save folder path
            `pages_range:` range of pages to save
                    Example: `-10, !8, 12, 14-20, !15-17, 30-40/2, 50-60/3, 70-`
                    -10:   Download from page 1 to 10
                    !8:   Exclude page 8
                    12:   Download page 12
                    14-20:   Download from page 14 to 20
                    !15-17:   Exclude page 15 to 17
                    30-40/2:   Download every 2nd page between 30-40 (30, 32, 34, 36, 38, 40)
                    50-60/3:   Download every 3rd page between 50-60 (50, 53, 56, 59)
                    70-:   Download from page 70 to the last page
            `concurrent_images:` number of images to download at a time
            `retries:` number of retries for failed to download images
        """
        if not os.path.exists(save_path): raise IOError(f"No such directory: '{save_path}'")
        full_path = os.path.join(save_path, self.cbz_name)
        images = self._get_range_images(pages_range) if pages_range else self.images
        if resize_image:
            images = ["https://replit.com/cdn-cgi/image/height=1800,quality=80,anim=true,format=webp/"+i for i in images]
        return self._make_tempzip(images, retries, concurrent_images, path = full_path)

    def cbz_in_bytes(self, pages_range:Optional[str]=None, concurrent_images:int=20, retries:int=10, resize_image=False) -> Tuple[str, BytesIO]:
        """ `pages_range:` range of pages to save
                    Example: `-10, !8, 12, 14-20, !15-17, 30-40/2, 50-60/3, 70-`
                    -10:   Download from page 1 to 10
                    !8:   Exclude page 8
                    12:   Download page 12
                    14-20:   Download from page 14 to 20
                    !15-17:   Exclude page 15 to 17
                    30-40/2:   Download every 2nd page between 30-40 (30, 32, 34, 36, 38, 40)
                    50-60/3:   Download every 3rd page between 50-60 (50, 53, 56, 59)
                    70-:   Download from page 70 to the last page
            `concurrent_images:` number of images to download at a time
            `retries:` number of retries for failed to download images
        """
        file_name = self.cbz_name
        images = self._get_range_images(pages_range) if pages_range else self.images
        if resize_image:
            images = ["https://replit.com/cdn-cgi/image/height=1800,quality=80,anim=true,format=webp/"+i for i in images]
        zip_bytes = self._make_tempzip(images, retries, concurrent_images)
        return file_name, zip_bytes

    def __repr__(self) -> str:
        class_name = type(self).__name__
        return f'{class_name}(id="{self.id}", title="{self.title_pretty}")'
