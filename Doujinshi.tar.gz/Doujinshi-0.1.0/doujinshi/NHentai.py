from doujinshi.BaseDownloader import (
    Doujinshi,
    Union
)

class NHentai(Doujinshi):
    def __init__(self, info:Union[str,int]) -> None:
        """`info`: either full URL or just the ID"""
        super().__init__()
        self._site_map = {'fetch_url': "https://090ec697-d669-484b-bd89-678ae15c6531-00-2gdt1mtsgf2z5.picard.replit.dev/api/{id}", 're_check':[r'^\d+$', r'\:\/\/nhentai\.net', r'\:\/\/nhentai\.to', r'\:\/\/nhentai\.xxx'],'id_find': r'/\w+\/(\d+)','referer': 'https://nhentai.net/'}
        self._init(info)
        self.meta_data = dict()
        self.__info_extractor()

    def __info_extractor(self) -> None:
        data = self._requests(self.url)
        result = data.json()['result']
        self.title = result['title']['japanese']
        self.title_pretty = self._pretty_title(result['title']['english'])
        self.meta_data = result['tags']
        self.images = result['images']['full']
        self.cbz_name = self._cbz_name(self.title_pretty, f'nhentai.net ({self.id})' ,self.meta_data.get('artist'), self.meta_data.get('group'))
