from doujinshi.BaseHeantaiEra import BaseHentaiEra
from typing import Union

class ImHentaiXXX(BaseHentaiEra):
    def __init__(self, info:Union[str,int]) -> None:
        """`info`: either full URL or just the ID"""
        super().__init__()
        self._site_map = {'re_check':[r'^\d+$', r'\:\/\/imhentai\.xxx'],'id_find': r'/\w+\/(\d+)','referer': 'https://imhentai.xxx/','fetch_url': "https://imhentai.xxx/gallery/{id}/"}
        self._init(info)
        self._title_selector = "div.right_details > h1"
        self._cover_selector = "div.left_cover img"
        self._tag_name_selector = "ul.galleries_info span.tags_text"
        self._tags_sibling_selector = 'a.tag'
        self._info_extractor()