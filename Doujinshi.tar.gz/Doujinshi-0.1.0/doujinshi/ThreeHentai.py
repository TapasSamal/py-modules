from doujinshi.BaseDownloader import (
    Doujinshi,
    Union
)

class ThreeHentai(Doujinshi):
    def __init__(self, info:Union[str,int]) -> None:
        """`info`: either full URL or just the ID"""
        super().__init__()
        self._site_map = {'re_check':[r'^\d+$', r'\:\/\/3hentai\.net'],'id_find': r'/\w+\/(\d+)','referer': 'https://3hentai.net/','fetch_url': "https://3hentai.net/d/{id}"}
        self._init(info)
        self.meta_data = dict()
        self.__info_extractor()

    def __info_extractor(self):
        soup = self._make_soup(self._requests(self.url).content)
        self.images = [img['data-src'].replace('t.','.') for img in soup.select('#thumbnail-gallery .single-thumb > a > img')]
        info = soup.select_one("div#main-info")
        self.title = info.select_one("h1").text
        middle_title = info.select_one("h1 > .middle-title")
        self.title_pretty = self.title if middle_title is None else self._pretty_title(middle_title.text)
        for i in info.select("div.tag-container.field-name"):
            info_list = list(i.stripped_strings)
            self.meta_data[info_list[0][:-1].lower()] = info_list[1:]
        self.cbz_name = self._cbz_name(self.title_pretty, f'3hentai.net ({self.id})' ,self.meta_data.get('artists'), self.meta_data.get('groups'))