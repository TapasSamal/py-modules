import os
import requests
import re
# import threading
from typing import Optional, List
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlparse, unquote

def combine_segments(segment_filenames:List[str], output_filename:str):
    with open(output_filename, "wb") as output_file:
        for segment_filename in segment_filenames:
            with open(segment_filename, "rb") as segment_file:
                output_file.write(segment_file.read())
            os.remove(segment_filename)
    print("[COMBINING] " + output_filename)

def convert_bytes(bytes_length:int):
    s, i = ['b', 'kb', 'mb', 'gb', 'tb'], 0
    while bytes_length >= 1024:
        bytes_length /= 1024
        i +=1
    return f"{round(bytes_length, 2)} {s[i]}"

def get_file_name(url:str, dispatch:Optional[str]) -> str:
    if dispatch:
        dis_filename = re.findall(r'filename="([^"]+)"', dispatch)
        if len(dis_filename) != 0:
            return dis_filename[0]
    return unquote(urlparse(url).path.split("/")[-1])

def download_segment(
        url:str,
        start_byte:int,
        end_byte:int,
        segment_num:int,
        full_path:str,
        headers:dict,
        segment_size:int,
        total_retries:int,
        nth_retries:int=1
    ):
    if headers is None:
        headers = {}
    headers["Range"] = f"bytes={start_byte}-{end_byte}"
    try:
        response = requests.get(url, headers=headers, stream=True, timeout=(3.05*4, None))
        file_name = os.path.basename(full_path)
        if response.status_code in [206, 200] :
            segment_filename = full_path + f".{segment_num}.part"
            with open(segment_filename, "wb") as f:
                for chunk in response.iter_content(chunk_size=(segment_size // 100)):
                    if not chunk:
                        break
                    f.write(chunk)
            print(f"[{file_name}] - {segment_num} Downloaded")
            return segment_filename
        elif nth_retries <= total_retries:
            r = nth_retries + 1
            print(f"[Warn] Segment {segment_num} got '{response.status_code}' retrying ({nth_retries}/{total_retries})")
            return download_segment(
                url=url, start_byte=start_byte, end_byte=end_byte,
                segment_num=segment_num, full_path=full_path,
                headers=headers,segment_size=segment_size,
                total_retries=total_retries, nth_retries=r)
        else:
            print(f"[ERROR] {file_name} - {segment_num}. status_code: {response.status_code}")
            return None
    except Exception as e :
        if nth_retries <= total_retries:
            print(f"[WARN] Segment{segment_num} got DOWNLOAD ERROR' retrying ({nth_retries}/{total_retries})\n{e}")
            r = nth_retries + 1
            return download_segment(
                url=url, start_byte=start_byte, end_byte=end_byte,
                segment_num=segment_num, full_path=full_path,
                headers=headers,segment_size=segment_size,
                total_retries=total_retries, nth_retries=r)
        else:
            print(f"[ERROR] {file_name} - {segment_num}. download failed")
            return None

def segment_downloader(
        url:str,
        output_folder:str,
        output_name:str, 
        headers:Optional[dict],
        file_size:int,
        num_segments:int,
        conc_downloads:int,
        total_retries:int
    ):
    segment_size = file_size // num_segments
    size = convert_bytes(segment_size)
    print("SegmentSize: "+size)

    threads = []
    full_path = os.path.join(output_folder, output_name)
    for i in range(num_segments):
        start_byte = i * segment_size
        end_byte = start_byte + segment_size - 1
        if i == num_segments - 1:
            end_byte = ""
        threads.append(
            (url, start_byte, end_byte, i, full_path, headers, segment_size, total_retries, 1) # 1 is the nth_retry
        )

    with ThreadPoolExecutor(conc_downloads) as work:
        [work.submit(lambda p: download_segment(*p), a) for a in threads]

    segment_filenames = []
    for i in range(num_segments):
        segment_filename = full_path + f".{i}.part"
        if os.path.exists(segment_filename):
            segment_filenames.append(segment_filename)
        else:
            print(f"missing segment: {i}")
    combine_segments(segment_filenames, full_path)

def non_segment_downloader(
        url:str,
        headers:Optional[dict]=None,
        output_folder:Optional[str]=None,
        output_name:Optional[str]=None
    ):
    response = requests.get(url, headers=headers, stream=True, timeout=(3.05*5, None))

    full_path = os.path.join(output_folder, output_name) if output_folder else output_name
    file_size = int(response.headers["content-length"])
    chunk_size = file_size//500
    if response.ok:
        with open(full_path, "wb") as f:
            for chunk in response.iter_content(chunk_size):
                if not chunk:
                    break
                f.write(chunk)
    else:
        raise ValueError(f"{url} return status code {response.status_code}")

def download(
        url:str,
        headers:Optional[str]=None,
        file_name:Optional[str]=None,
        save_path:Optional[str]=None,
        retries:int=10,
        concurrent:int=5,
        segments:int=10
    ):
    """
    `file_name:` file name [WITH IT'S EXTENSION]
    `segments:` split the file into N segments
    `concurrent:` download N segments concurrently
    `retries:` N retries after a failed segment download
    `url:` URL of the file
    `headers:` headers for requests (None by default)
    `save_path`: save folder (Working DIR by default)
    """
    response = requests.head(url, allow_redirects=True, headers=headers, timeout=(3.05*3, None))
    try:
        file_size = int(response.headers["content-length"])
    except KeyError:
        for k, v in response.headers.items():
            print(k + " : " + v)
        print("HTTP Code : ", response.status_code)
        raise KeyError()
    size = convert_bytes(file_size)
    url = response.url
    
    if not file_name:
        file_name = get_file_name(
            url,
            response.headers.get("content-disposition")
        )

    if save_path:
        os.makedirs(save_path, exist_ok=True)
    else:
        save_path = ''

    print(f"downloading: {file_name} ({size})")
    accept_ranges = response.headers.get("accept-ranges")
    if accept_ranges is not None and 'bytes' in accept_ranges:
        segment_downloader(
            url=url,
            output_folder=save_path,
            output_name=file_name,
            headers=headers,
            file_size=file_size,
            num_segments=segments,
            conc_downloads=concurrent,
            total_retries=retries
        )
    else:
        print("[WARNING] URL doesn't supports partial download")
        non_segment_downloader(url, headers, save_path, file_name, file_size)
    print("[DOWNLOADED] " + file_name)

