from setuptools import setup
setup(
    name='video-downloader',
    version='0.0.10',
    description='A simple Python package to files specially videos',
    author='Tapas Samal',
    author_email='tapas.samal@yandex.com',
    install_requires=['requests']
)
