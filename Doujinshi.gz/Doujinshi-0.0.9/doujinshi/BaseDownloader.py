from requests import request, Response
from urllib.parse import urlparse
from typing import Optional, Union, Tuple
from bs4 import BeautifulSoup
from zipfile import ZipFile
from io import BytesIO
from concurrent.futures import ThreadPoolExecutor
import os
import regex as re # [ pip install regex ] (built-in re did not support `recursive patterns`)
from doujinshi.errors import *

class Doujinshi:
    def __init__(self) -> None:
        self.headers = {"Referer": "","User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"}
        self._n_sort_image_name = True
        self._image_name_split = '/'

    def _init(self, info:Union[str,int]) -> None:
        info = str(info)
        self._check_validity(info, self._site_map['re_check'])
        self.id = self._get_id(self._site_map['id_find'], info)
        self.headers['Referer'] = self._site_map['referer']
        self.url = self._site_map['fetch_url'].format(id=self.id)

    def _pretty_title(self, title:str) -> str:
        clear_brackets = re.sub(
            r'([\[(][^[\]()]*(?:(?R)[^[\]()]*)*[\])])', '' , title
        )
        clean_space = re.sub("\s{2,}", " ", clear_brackets)
        splited = clean_space.split('|')
        splited = clear_brackets.split('|')
        return splited[-1].strip() if splited[-1].strip() != "" else splited[0].strip()

    def _cbz_name(self, title:str, site_domain:str, artist:Optional[list[str]]=None, group:Optional[list[str]]=None) ->str:
        add = ""
        if artist != None:add = f" [{', '.join(artist)}]"
        elif group != None:add = f" [{', '.join(group)}]"
        return self._sanitize_filename(title + add +f" [{site_domain}].cbz")

    def _check_validity(self, info:Union[str, int], patterns:list):
        valid = False
        for p in patterns:
            valid = self._regex_exist(p, info)
            if valid:break
        if not valid: raise DoujinSiteError(f"`{info}` is not a valid arg for this class")

    def _regex_exist(self, pattern:str, text:str) -> bool:
        return bool(re.search(pattern, text, re.I))

    def _get_id(self, pattern:str, url:str) -> str:
        finds = re.findall(r'^\d+$', url, re.I)
        if len(finds) != 0: return finds[0]
        finds = re.findall(pattern, url, re.I)
        if len(finds) == 0: raise MatchFoundError(f"no ID found in `{url}`")
        else: return finds[0]

    def _requests(self, url:str, method:str="GET", data:Optional[dict]=None, stream:Optional[bool]=None, allow_redirects:bool=True) -> Response:
        req = request(method, url, data=data, stream=stream, allow_redirects=allow_redirects, headers=self.headers)
        if not req.ok:
            parsed_url = urlparse(req.url)
            raise ConnectionError(f"status_code: {req.status_code}, domain:{parsed_url.netloc}, path: {parsed_url.path}")
        return req

    def _make_soup(self, html_content:Union[str,bytes]):
        return BeautifulSoup(html_content, 'html.parser')

    def _sanitize_filename(self, string:str) -> str:
        res = ''
        def replace_(char):
            return {'/': '\u29F8', '\\': '\u29f9'}.get(char, chr(ord(char) + 0xfee0)) if char in '"*:<>?|/\\' else char
        for c in string:res = res + replace_(c)
        return res

    def _make_tempzip(self, images:list[str], remove_cover=False, total_retries:int=10, concurrent_downloads:int = 20):
        filename_split, natural_sort = self._image_name_split, self._n_sort_image_name
        temp_zip = BytesIO()
        ZIP=ZipFile(temp_zip, 'w')
        if remove_cover:images = images[1:]
        total_images_decimal = len(str(len(images)))

        def image_name_maker(image_name:str, do_sort=True) -> str:
            if not do_sort: return image_name
            img_n, _ = os.path.splitext(image_name)
            add_ = '0' * (total_images_decimal - len(img_n))
            return add_ + image_name

        def thread_image_handel(img_url:str)->None:
            img = self._requests(img_url, stream=True)
            img_name = image_name_maker(img_url.split(filename_split)[-1], natural_sort)
            if not img.ok:print('err ', img.status_code, " :: img_name '", img_name,"'")
            else:ZIP.writestr(img_name,img.content)

        def process(urls:list,tries=1):
            with ThreadPoolExecutor(max_workers=concurrent_downloads) as e:e.map(thread_image_handel,urls)
            not_downloaded = [item for item in urls if image_name_maker(item.split(filename_split)[-1], natural_sort) not in ZIP.namelist()]
            if len(not_downloaded) != 0 and tries > total_retries:raise ChildProcessError("[Error] Could not download all files")
            elif len(not_downloaded) != 0:tries += 1;process(not_downloaded,tries)

        process(images)
        ZIP.close()
        temp_zip.seek(0)
        return temp_zip

    def download_cbz(self, save_path:str, skip_cover:bool=False, concurrent_images:int=20, retries:int=10) -> None:
        if not os.path.exists(save_path): raise IOError(f"No such directory: '{save_path}'")
        full_path = os.path.join(save_path, self.cbz_name)
        with open(full_path, 'wb') as f:
            zip_bytes = self._make_tempzip(self.images, skip_cover, retries, concurrent_images)
            f.write(zip_bytes.getvalue())

    def cbz_in_bytes(self, skip_cover:bool=False, concurrent_images:int=20, retries:int=10) -> Tuple[str, BytesIO]:
        file_name = self.cbz_name
        zip_bytes = self._make_tempzip(self.images, skip_cover, retries, concurrent_images)
        return file_name, zip_bytes

    def __repr__(self) -> str:
        class_name = type(self).__name__
        return f'{class_name}(id="{self.id}", title="{self.title_pretty}")'