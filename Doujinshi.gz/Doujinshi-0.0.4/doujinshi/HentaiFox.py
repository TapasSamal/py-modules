from doujinshi.BaseDownloader import Doujinshi
import re
from typing import Union
import json

class HentaiFox(Doujinshi):
    def __init__(self, info:Union[str,int]) -> None:
        """`info`: either full URL or just the ID"""
        super().__init__()
        self._site_map = {'re_check':[r'^\d+$', r'\:\/\/hentaifox\.com\/'],'id_find': r'/\w+\/(\d+)','referer': 'https://hentaifox.com/','fetch_url': "https://hentaifox.com/gallery/{id}/"}
        self._init(info)
        self.meta_data = dict()
        self.__info_extractor()
    def __info_extractor(self):
        soup = self._make_soup(self._requests(self.url).content)
        self.title, load_dir, load_id = tuple(map(lambda a:soup.find('input',{'id':a})['value'], ['gallery_title', 'load_dir', 'load_id']))
        image_domain = "https://i2.hentaifox.com/"
        self.title_pretty = self._pretty_title(self.title)
        artists, groups, parodies, characters, tags, languages, categories = tuple(map(
            lambda x: None if len(soup.select(f'div.info > ul.{x} a.tag_btn')) == 0 else [list(tag.stripped_strings)[0] for tag in soup.select(f'div.info > ul.{x} a.tag_btn')],
            ['artists', 'groups', 'parodies', 'characters', 'tags', 'languages', 'categories']
        ))
        self.meta_data={'artists':artists, 'groups':groups, 'parodies':parodies,'characters':characters, 'tags':tags, 'languages':languages, 'categories':categories}
        image_format_data, self.images = {'j':'jpg','p':'png','g':'gif'}, list()
        for k, v in json.loads(re.search(r"parseJSON\(\'(.+)\'\)", soup.prettify()).group(1)).items():
            try:self.images.append(image_domain + load_dir + f"/{load_id}/{k}.{image_format_data[v.split(',')[0]]}")
            except KeyError:raise KeyError(f"no key `{v.split(',')[0]}` found in image_format_data (image number: {k})")
        self.cbz_name = self._cbz_name(self.title_pretty, f'hentaifox.com ({self.id})' ,self.meta_data.get('artists'), self.meta_data.get('groups'))