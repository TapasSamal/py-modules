from doujinshi.DoujinsCom import DoujinsCom
from doujinshi.DoujinSexy import DoujinSexy
from doujinshi.HentaiFox import HentaiFox
from doujinshi.Hitomi import Hitomi
from doujinshi.NHentai import NHentai
from doujinshi.NineHentai import NineHentai
from doujinshi.ThreeHentai import ThreeHentai
from doujinshi.Hentai2Read import Hentai2Read