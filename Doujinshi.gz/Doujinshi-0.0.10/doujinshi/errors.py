class MatchFoundError(Exception):
    pass
class DoujinSiteError(Exception):
    pass
class RegexPatternError(Exception):
    pass