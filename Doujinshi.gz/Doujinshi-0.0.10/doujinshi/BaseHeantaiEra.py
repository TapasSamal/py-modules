from doujinshi.BaseDownloader import (
    Doujinshi,
    re,
    urlparse
)
import json

class BaseHentaiEra(Doujinshi):
    def _info_extractor(self):
        self.meta_data = dict()
        soup = self._make_soup(self._requests(self.url).content)
        self.title = soup.select_one(self._title_selector).string.strip()
        self.title_pretty = self._pretty_title(self.title)

        to_extract = ['artists', 'groups', 'parodies', 'characters', 'tags', 'languages', 'category']
        tag_name_clean = lambda t: re.sub(r'\W','',t.string.lower().strip())
        for t in soup.select(self._tag_name_selector):
            tag_name = tag_name_clean(t)
            if tag_name in to_extract:
                tag_values = [list(v.stripped_strings)[0] for v in t.parent.select(self._tags_sibling_selector)]
                self.meta_data[tag_name] = tag_values

        cover = soup.select_one(self._cover_selector)
        cover_url = cover.get('data-src') if cover.get('data-src') is not None else cover.get('src')
        image_netloc = urlparse(cover_url).netloc
        load_dir, load_id = tuple(map(lambda a:soup.find('input',{'id':a})['value'], ['load_dir', 'load_id']))
        image_format_data, self.images = {'j': '.jpg', 'p': '.png', 'b': '.bmp', 'g': '.gif'}, list()
        for k, v in json.loads(re.search(r"parseJSON\(\'(.+)\'\)", soup.prettify()).group(1)).items():
            try:self.images.append(f"https://{image_netloc}/{load_dir}/{load_id}/{k}{image_format_data[v.split(',')[0]]}")
            except KeyError:raise KeyError(f"no key `{v.split(',')[0]}` found in image_format_data (image number: {k})")
        self.cbz_name = self._cbz_name(self.title_pretty, f'{urlparse(self.url).netloc} ({self.id})' ,self.meta_data.get('artists'), self.meta_data.get('groups'))
