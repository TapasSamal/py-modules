from doujinshi.BaseDownloader import (
    Doujinshi,
    Tuple,
    Optional,
    BytesIO,
    re
)
import json
from prettytable import PrettyTable

class Hentai2Read(Doujinshi):
    def __init__(self, URL:str) -> None:
        """`info`: only provide full URL"""
        super().__init__()
        self._site_map = {'re_check':[r'\:\/\/hentai2read\.com'],'id_find': r'^(.+\/{2}[^\/]+\/[^\/]+\/?)','referer': 'https://hentai2read.com/','fetch_url': "{id}"}
        self._init(URL)
        self._n_sort_image_name = False
        self._image_name_split = '?'
        self.__image_domain = "https://img3.hentaicdn.com/hentai"
        self.meta_data, self.__chapter_image_urls = dict(), dict()
        self.__info_extractor()

    def download_cbz(self, save_path:str, pages_range:Optional[str]=None, concurrent_images:int=20, retries:int=10) -> None:
        """this will all chapters into one CBZ file"""
        self.__make_all_cbz_data()
        super().download_cbz(save_path, pages_range, concurrent_images, retries,)
    def cbz_in_bytes(self, pages_range:Optional[str]=None, concurrent_images:int=20, retries:int=10) -> Tuple[str, BytesIO]:
        """this will all chapters into one CBZ file"""
        self.__make_all_cbz_data()
        file_name, zip_bytes = super().cbz_in_bytes(pages_range, concurrent_images, retries)
        return file_name, zip_bytes
    def download_chapter_cbz(self, chapter_number:int, save_path:str, pages_range:Optional[str]=None, concurrent_images:int=20, retries:int=10) -> None:
        self.__make_chapter_data(chapter_number)
        super().download_cbz(save_path, pages_range, concurrent_images, retries)
    def cbz_in_bytes(self, chapter_number:int, pages_range:Optional[str]=None, concurrent_images:int=20, retries:int=10) -> Tuple[str, BytesIO]:
        self.__make_chapter_data(chapter_number)
        file_name, zip_bytes = super().cbz_in_bytes(pages_range, concurrent_images, retries)
        return file_name, zip_bytes

    @property
    def chapters(self) -> None:
        print(self.__chapters_table)

    def __get_chapter_images(self, ch_data:dict) -> list[str]:
        image_urls = self.__chapter_image_urls.get(ch_data['chapter_prefix'])
        if image_urls is not None:
            return image_urls
        ch_page = self._requests(ch_data['chapter_link']).text
        img_uris = re.search("gdata[\w\W]+\'images\'[^\[]+(.+\])", ch_page, re.I).group(1)
        image_urls = [self.__image_domain + i + f"?{ch_data['chapter_prefix']}-{i.split('/')[-1]}" for i in json.loads(img_uris)]
        self.__chapter_image_urls[ch_data['chapter_prefix']] = image_urls
        return image_urls

    def __clear_cbz_data(self):
        self.images, self.cbz_name = [], ''

    def __make_all_cbz_data(self):
        self.__clear_cbz_data()
        self.images, self.cbz_name = [], ''
        for k, v in self.__chapters.items():
            self.images += self.__get_chapter_images(v)
        self.cbz_name = self._cbz_name(self.title_pretty, f'hentai2read.com ({self.id})' ,self.meta_data.get('artist'))

    def __make_chapter_data(self, chapter_number):
        self.__clear_cbz_data()
        chapter_data = self.__chapters.get(chapter_number)
        if chapter_data is None:
            raise KeyError(f"no chapter found for chapter number '{chapter_number}'")
        self.images = self.__get_chapter_images(chapter_data)
        prefix = f"[{self.id} ({chapter_data['chapter_prefix']})] " if len(self.__chapters) > 1 else f"[{self.id} "
        self.cbz_name = self._cbz_name(prefix + chapter_data['title'], f'hentai2read.com' ,self.meta_data.get('artist'))

    def __info_extractor(self) -> None:
        soup = self._make_soup(self._requests(self.url).content)
        self.title = soup.select_one("h3.block-title a").text.strip()
        self.title_pretty = self.title
        self.id = 'M' + soup.select_one('a.js-addBookmark')['data-mid']
        self.__chapters = {}
        chapters_li = soup.select("ul.nav-chapters > li")
        total_decimal = len(str(len(chapters_li)))
        total_decimal = 2 if total_decimal < 2 else total_decimal
        chapter_name = lambda ch_num: 'Ch' + '0' * (total_decimal - len(str(ch_num))) + str(ch_num)

        for num, chapter in enumerate(chapters_li[::-1], 1):
            chapter_anch = chapter.select_one("a.pull-left")
            self.__chapters[num] = {
                'title':re.sub(r"^\d+[^\w\d]+", "", list(chapter_anch.stripped_strings)[0]),
                'chapter_link':chapter_anch['href'],"chapter_prefix":chapter_name(num)}

        for data in soup.select("ul.list-simple-mini > li.text-primary"):
            listed_tags = list(data.stripped_strings)
            if not(listed_tags[1] == '-' or listed_tags[0].lower() in ['ranking', 'page', 'view', 'storyline']):
                self.meta_data[listed_tags[0].lower()] = listed_tags[1:]
        table = PrettyTable()
        table.field_names = ["Chapter", "Title"]
        for k, v in self.__chapters.items():table.add_row([k, v['title']])
        self.__chapters_table = str(table)