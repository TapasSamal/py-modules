from doujinshi.BaseDownloader import (
    Doujinshi,
    urlparse,
    os
)

class DoujinsCom(Doujinshi):
    def __init__(self, info:str) -> None:
        """`info`: only provide full URL"""
        super().__init__()
        self._site_map = {'re_check':[r'\/\/doujins\.com\/'], 'id_find':r'\/(.+)$', 'referer':'https://doujins.com/', 'fetch_url':"https://doujins.com/{id}"}
        self._init(info)
        self.meta_data = dict()
        self.__info_extractor()
        self._image_name_split = '&'

    def __info_extractor(self):
        soup = self._make_soup(self._requests(self.url).content)
        self.title = soup.select_one("div.folder-display a:nth-last-child(1)").string
        self.title_pretty = self._pretty_title(self.title)
        self.images = [
            i['data-src'] + f"&{n}{os.path.splitext(urlparse(i['data-src']).path)[1]}" for n, i in enumerate(
                soup.select("div#toggle-column .swiper-zoom-container > img"), start=1
                )
            ]
        self.meta_data['tags'] = [x.string for x in soup.select('div.d-block li.tag-area a')]
        self.meta_data['artist'] = None if len(soup.select("div.gallery-artist > a")) == 0 else [a.string for a in soup.select("div.gallery-artist > a")]
        self.cbz_name = self._cbz_name(self.title_pretty, 'doujins.com', self.meta_data.get('artist'))