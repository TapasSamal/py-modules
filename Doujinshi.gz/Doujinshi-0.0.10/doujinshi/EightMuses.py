from doujinshi.BaseDownloader import (
    Doujinshi,
    DoujinSiteError,
    os
)

class EightMuses(Doujinshi):
    def __init__(self, info:str) -> None:
        """`info`: only provide full URL"""
        super().__init__()
        self._site_map = {'re_check':[r'\:\/\/comics\.8muses\.com'],'id_find': r'^(.+)$','referer': 'https://comics.8muses.com/','fetch_url': "{id}"}
        self._init(info)
        self._image_name_split = '?'
        self.__image_domain = "https://comics.8muses.com/image/fm/"
        self.meta_data=None
        self.__info_extractor()

    def __title_parser(self, soup) -> None:
        crumb = list(soup.select_one('div.top-menu-breadcrumb').stripped_strings)
        if crumb[0] in ['Fakku Comics', 'Various Authors', 'Hentai and Manga English']: crumb = crumb[1:]
        self.title = ' - '.join(crumb[1:])
        self.title_pretty = self._pretty_title(self.title)
        self.cbz_name = self.title_pretty + f" [{crumb[0]}] [8muses.com].cbz"

    def __info_extractor(self):
        soup = self._make_soup(self._requests(self.url).content)
        items = soup.select('a.c-tile.t-hover')
        if items[0].select_one('span.title-text') is not None:
            raise DoujinSiteError("Not a comic page")

        images_names = [item.find('img')['data-src'].split('/')[-1] for item in items]
        self.images = [self.__image_domain + img + f"?{ind}{os.path.splitext(img)[1]}" for ind, img in enumerate(images_names, 1)]
        self.__title_parser(soup)
        self.id = self.url.strip('/').replace("https://comics.8muses.com/comics/album/", "")