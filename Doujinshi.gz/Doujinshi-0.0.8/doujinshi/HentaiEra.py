from doujinshi.BaseHeantaiEra import BaseHentaiEra
from typing import Union

class HentaiEra(BaseHentaiEra):
    def __init__(self, info:Union[str,int]) -> None:
        """`info`: either full URL or just the ID"""
        super().__init__()
        self._site_map = {'re_check':[r'^\d+$', r'\:\/\/hentaiera\.com'],'id_find': r'/\w+\/(\d+)','referer': 'https://hentaiera.com/','fetch_url': "https://hentaiera.com/gallery/{id}/"}
        self._init(info)
        self._title_selector = "div.gallery_first > h1"
        self._cover_selector = "div.left_cover img"
        self._tag_name_selector = "ul.galleries_info span.tags_text"
        self._tags_sibling_selector = 'div.info_tags > a.tag'
        self.meta_data = dict()
        self._info_extractor()