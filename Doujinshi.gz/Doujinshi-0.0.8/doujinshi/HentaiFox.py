from doujinshi.BaseHeantaiEra import BaseHentaiEra
from typing import Union

class HentaiFox(BaseHentaiEra):
    def __init__(self, info:Union[str,int]) -> None:
        """`info`: either full URL or just the ID"""
        super().__init__()
        self._site_map = {'re_check':[r'^\d+$', r'\:\/\/hentaifox\.com'],'id_find': r'/\w+\/(\d+)','referer': 'https://hentaifox.com/','fetch_url': "https://hentaifox.com/gallery/{id}/"}
        self._init(info)
        self._title_selector = "div.info > h1"
        self._cover_selector = "div.cover > img"
        self._tag_name_selector = "div.info span.i_text"
        self._tags_sibling_selector = 'li > a'
        self.meta_data = dict()
        self._info_extractor()