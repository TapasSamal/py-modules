from doujinshi.BaseDownloader import Doujinshi
from typing import Union

class Tsumino(Doujinshi):
    def __init__(self, info:Union[str,int]) -> None:
        """`info`: either full URL or just the ID"""
        super().__init__()
        self._site_map = {'re_check':[r'^\d+$', r'\:\/\/(?:[^\.]+\.)?tsumino\.com\/'],'id_find': r'\/(\d+)(?:\?.+)?$','referer': 'https://www.tsumino.com/','fetch_url': "https://www.tsumino.com/entry/{id}"}
        self._init(info)
        self._image_name_split = '&'
        self.meta_data = dict()
        self.__info_extractor()

    @property
    def images(self) -> list[str]:
        images = getattr(self, '__images', None)
        if images: return images
        soup = self._make_soup(self._requests("https://www.tsumino.com/Read/Index/" + self.id).content)
        img_ = soup.select_one("div#image-container")['data-cdn']
        image_map = img_.replace('[', '{').replace(']', '}') + '&{PAGE}.jpg'
        images = list(map(lambda x: image_map.format(PAGE=x), range(1, self.__pages+1)))
        setattr(self, '__images', images)
        return images

    def __info_extractor(self):
        soup = self._make_soup(self._requests(self.url).content)
        self.title = soup.find('div',{'id': 'Title'}).text.strip()
        self.__pages = int(soup.find('div',{'id': 'Pages'}).text.strip())
        title_pretty = self._pretty_title(self.title).split('/')
        self.title_pretty = title_pretty[0].strip() if len(title_pretty) < 3 else title_pretty[1].strip()
        metadata_id = ['Category', 'Group', 'Artist', 'Parody', 'Character', 'Tag', 'Collection']
        for meta_id in metadata_id:
            meta_div = soup.find('div',{'id': meta_id})
            if meta_div: self.meta_data[meta_id.lower()] = [a['data-define'] for a in meta_div.find_all('a')]
        self.cbz_name = self._cbz_name(self.title_pretty, f'tsumino.com ({self.id})' ,self.meta_data.get('artist'), self.meta_data.get('group'))