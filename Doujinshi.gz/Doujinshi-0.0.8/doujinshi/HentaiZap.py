from doujinshi.BaseHeantaiEra import BaseHentaiEra
from typing import Union

class HentaiZap(BaseHentaiEra):
    def __init__(self, info:Union[str,int]) -> None:
        """`info`: either full URL or just the ID"""
        super().__init__()
        self._site_map = {'re_check':[r'^\d+$', r'\:\/\/hentaizap\.com'],'id_find': r'/\w+\/(\d+)','referer': 'https://hentaizap.com/','fetch_url': "https://hentaizap.com/gallery/{id}/"}
        self._init(info)
        self._title_selector = "div.gp_top_right > h1"
        self._cover_selector = "div.gp_cover > img"
        self._tag_name_selector = "div.gp_top_right_info span.info_txt"
        self._tags_sibling_selector = 'li > a.gp_btn_tag '
        self.meta_data = dict()
        self._info_extractor()