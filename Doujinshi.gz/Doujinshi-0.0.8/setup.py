from setuptools import setup, find_packages

setup(
    name='Doujinshi',
    version='0.0.8',
    description='A Python package to downlaod Doujinshi from various websites',
    author='Tapas Samal',
    packages=find_packages(),
    author_email='tapas.samal@yandex.com',
    install_requires=['regex','beautifulsoup4']
)

# python setup.py sdist bdist_wheel