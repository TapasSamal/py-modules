from doujinshi.modules import *
import re

class GenericDownloaderError(Exception):
    pass

PATTERN_CLASS_MAP = {
    r'\/\/doujins\.com\/': DoujinsCom,
    r'\:\/\/doujin\.sexy\/': DoujinSexy,
    r'\:\/\/hentaifox\.com\/' : HentaiFox,
    r'\:\/\/hitomi\.la': Hitomi,
    r'\:\/\/nhentai\.net': NHentai, 
    r'\:\/\/nhentai\.to': NHentai, 
    r'\:\/\/nhentai\.xxx': NHentai,
    r'\:\/\/9hentai\.to\/': NineHentai,
    r'\:\/\/3hentai\.net': ThreeHentai,
    r'\:\/\/hentai2read\.com': Hentai2Read
}
def doujin_download(full_url:str):
    """`full_url :` Full URL of a Doujin"""
    for pattern, class_ in PATTERN_CLASS_MAP.items():
        if bool(re.search(pattern, full_url, re.I)):
            return class_(full_url)
    raise GenericDownloaderError(f"No downloader found for URL: `{full_url}`")