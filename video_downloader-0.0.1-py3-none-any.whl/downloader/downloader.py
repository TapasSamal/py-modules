import os
import requests
import threading
from urllib.parse import urlparse, unquote

def download_segment(url, start_byte, end_byte, segment_num, title, ret=1):
    headers = {'Range': f'bytes={start_byte}-{end_byte}'}
    response = requests.get(url, headers=headers, stream=True)

    if response.status_code == 206:  # Partial content response
        segment_filename = title+ f".part-{segment_num}"
        with open(segment_filename, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        print(f"[{title}] - {segment_num} Downloaded")
        return segment_filename
    elif response.status_code == 503 and ret < 5:
      r=ret+1
      return download_segment(url, start_byte, end_byte, segment_num, title,1)
    else:
        print(f"[Error] {title} - {segment_num}. status_code: {response.status_code}")
        return None

def convert_bytes(byte_value, target_unit='auto', precision=2):
    units = {'B': 1, 'KB': 1024, 'MB': 1024 ** 2, 'GB': 1024 ** 3, 'TB': 1024 ** 4}
    if target_unit == 'auto':
        for unit in ['TB', 'GB', 'MB', 'KB', 'B']:
            if byte_value >= units[unit]:
                target_unit = unit
                break
    if target_unit not in units:
        raise ValueError("Invalid target unit. Use 'B', 'KB', 'MB', 'GB', or 'TB'.")
    converted_value = byte_value / units[target_unit]
    formatted_value = round(converted_value, precision)

    return formatted_value, target_unit

def combine_segments(segment_filenames, output_filename):
    with open(output_filename, 'wb') as output_file:
        for segment_filename in segment_filenames:
            with open(segment_filename, 'rb') as segment_file:
                output_file.write(segment_file.read())
            os.remove(segment_filename)
    print("[COMBINING] "+output_filename)

def split_and_download(url, num_segments, output_name, output_folder = "/content"):
    response = requests.head(url, allow_redirects=True)
    # print(response.headers)
    try:
      size_, unit = convert_bytes(int(response.headers['content-length']))
    except KeyError:
      for k, v in response.headers.items():
        print(k + " : " + v)
      print("HTTP Code : ", response.status_code)
      raise KeyError()

    url = response.url
    file_size = int(response.headers['content-length'])
    segment_size = file_size // num_segments
    s_, u_ = convert_bytes(segment_size)
    print(f"TotalSize: {str(size_)+unit} // SegmentSize: {str(s_)+u_}")
    os.makedirs(output_folder, exist_ok=True)

    threads = []
    segment_filenames = []
    for i in range(num_segments):
        start_byte = i * segment_size
        end_byte = start_byte + segment_size - 1
        if i == num_segments - 1:
            end_byte = ''
        thread = threading.Thread(target=download_segment, args=(url, start_byte, end_byte, i, os.path.join(output_folder, output_name)))
        threads.append(thread)
        thread.start()

    for thread in threads:
        thread.join()

    for i in range(num_segments):
        segment_filename = os.path.join(output_folder, output_name + f".part-{i}")
        if os.path.exists(segment_filename):
            segment_filenames.append(segment_filename)

    combine_segments(segment_filenames, os.path.join(output_folder, output_name))
    print("[DOWNLOADED] " + output_name)

def auto_download(url, file_name=None):
  if file_name is None:
    file_name = unquote(urlparse(url).path.split('/')[-1])
  print(f"downloading: {file_name}")
  split_and_download(url,20,file_name)