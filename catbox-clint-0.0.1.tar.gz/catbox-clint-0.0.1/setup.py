from setuptools import setup
setup(
    name='catbox-clint',
    version='0.0.1',
    description='A simple Python package to uppload to catbox',
    author='Tapas Samal',
    author_email='tapas.samal@yandex.com',
    install_requires=['requests']
)