from requests import Response
import requests

class CatboxMoe:
    class CatboxMoeResponse:
        def __init__(self, res:Response) -> None:
            self.ok = res.ok
            self.status_code = res.status_code
            self.url = res.text if res.ok else ""
            self.msg = res.text if not res.ok else ""

        def json(self) ->dict:
            return {attr: getattr(self, attr) for attr in dir(self) if not callable(getattr(self, attr)) and not attr.startswith("__")}

        def __repr__(self) -> str:
            return f"CatboxMoeResponse(status_code={self.status_code})"

    def __init__(self, user_hash=""):
        """Leave `user_hash` Empty for Anonymous Upload"""
        self.__hash = user_hash
        self.__API_URL = "https://catbox.moe/user/api.php"
        self.__is_logged = False if user_hash == "" else True
        self.__data = {
            "reqtype": "",
            "userhash": self.__hash,
        }
        self.__headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Referer": "https://catbox.moe/"
        }

    def remote_upload(self, file_url:str):
        data = self.__data.copy()
        data['reqtype'] = 'urlupload'
        data['url'] = file_url
        return self.__post(data=data, headers=self.__headers)

    def file_upload(self, file_path:str):
        payload = {
            'reqtype': (None,'fileupload'),
            'userhash': (None, self.__hash),
            'fileToUpload': (file_path.split('/')[-1], open(file_path, 'rb'))
        }
        return self.__post(files=payload)

    def delete_files(self, file_names:list):
        """
        :file_names: `list of full file names e.g. ["eh871k.png", "d9pove.gif"]`\nif deleted successfully returns msg in `CatboxMoeResponse.url`
        """
        data = self.__data.copy()
        data['reqtype'] = 'deletefiles'
        data['files'] = " ".join(file_names)
        return self.__post(data=data, headers=self.__headers)

    def __post(self, data=None, headers=None, files=None) -> str:
        req = requests.post(self.__API_URL, data=data, headers=headers, files=files, timeout=240)
        return self.CatboxMoeResponse(req)

    def __repr__(self) -> str:
        if self.__hash == "":
            return "CatboxMoe(upload_type = anonymous)"
        return "CatboxMoe(upload_type = logged_in)"